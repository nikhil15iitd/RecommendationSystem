Change value of variable 'datadir' to the path where .csv files are present.

sklearn, numpy & pandas should be installed as python libraries.